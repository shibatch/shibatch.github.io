#include <immintrin.h>

#ifdef __SSE2__

typedef struct sincos_t {
  __m128d s, c;
} sincos_t;

sincos_t _mm_sincos_pd(__m128d d);
__m128d _mm_sin_pd(__m128d d);
__m128d _mm_cos_pd(__m128d d);
__m128d _mm_tan_pd(__m128d d);
__m128d _mm_atan_pd(__m128d d);
__m128d _mm_asin_pd(__m128d d);
__m128d _mm_acos_pd(__m128d d);
__m128d _mm_exp_pd(__m128d d);
__m128d _mm_log_pd(__m128d d);

#endif

//

#ifdef __AVX__

typedef struct sincos256_t {
  __m256d s, c;
} sincos256_t;

sincos256_t _mm256_sincos_pd(__m256d d);
__m256d _mm256_sin_pd(__m256d d);
__m256d _mm256_cos_pd(__m256d d);
__m256d _mm256_tan_pd(__m256d d);
__m256d _mm256_atan_pd(__m256d d);
__m256d _mm256_asin_pd(__m256d d);
__m256d _mm256_acos_pd(__m256d d);
__m256d _mm256_exp_pd(__m256d d);
__m256d _mm256_log_pd(__m256d d);

#endif
