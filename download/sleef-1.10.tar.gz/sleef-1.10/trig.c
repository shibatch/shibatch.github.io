#include <math.h>

typedef struct sincos_t { double s, c; } sincos_t;
   
#define N 3
   
sincos_t xsincos0(double s) {
  int i;
   
  // Argument reduction
  s = s * pow(2, -N);
   
  s = s*s; // Evaluating Taylor series
  s = ((((s/1814400 - 1.0/20160)*s + 1.0/360)*s - 1.0/12)*s + 1)*s;
   
  for(i=0;i<N;i++) { s = (4-s) * s; } // Applying double angle formula
  s = s / 2;
   
  sincos_t sc;
  sc.s = sqrt((2-s)*s);  sc.c = 1 - s;
  return sc;
}

#define PI4_A .7853981554508209228515625 // $\pi/4$ split into three parts
#define PI4_B .794662735614792836713604629039764404296875e-8
#define PI4_C .306161699786838294306516483068750264552437361480769e-16

// $4/\pi$
#define M_4_PI 1.273239544735162542821171882678754627704620361328125

sincos_t xsincos(double d) {
  double s = fabs(d);
  int q = (int)(s * M_4_PI), r = q + (q & 1);
   
  s -= r * PI4_A; s -= r * PI4_B; s -= r * PI4_C;

  sincos_t sc = xsincos0(s);
   
  if (((q + 1) & 2) != 0) { s = sc.c; sc.c = sc.s; sc.s = s; }
  if (((q & 4) != 0) != (d < 0)) sc.s = -sc.s;
  if (((q + 2) & 4) != 0) sc.c = -sc.c;
   
  return sc;
}
   
double xsin(double d) { sincos_t sc = xsincos(d); return sc.s; }
double xcos(double d) { sincos_t sc = xsincos(d); return sc.c; }
double xtan(double d) { sincos_t sc = xsincos(d); return sc.s / sc.c; }
