#include <math.h>

#define M_PI 3.14159265358979323846
#define N 2
   
double xatan(double d) {
  double x, y, z = fabs(d);
  if (z < 1.0) x = 1.0/z; else x = z;

  int i; // Applying cotangent half angle formula
  for(i = 0;i < N;i++) { x = x + sqrt(1+x*x); }
      
  x = 1.0 / x;
   
  y = 0; // Evaluating Taylor series
  for(i=10;i>=0;i--) { y = y*x*x + pow(-1, i)/(2*i+1); }
  y *= x * pow(2, N);

  if (z > 1.0) y = M_PI/2 - y;
  return d < 0 ? -y : y;
}

double xasin(double d) { return xatan(d / sqrt((1+d)*(1-d))); }
double xacos(double d) {
  return xatan(sqrt((1+d)*(1-d))/d) + (d < 0 ? M_PI : 0);
}
