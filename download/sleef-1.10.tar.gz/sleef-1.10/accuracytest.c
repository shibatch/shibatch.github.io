#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <inttypes.h>
#include <float.h>
#include <time.h>
#include <mpfr.h>

#include "sleef.h"

mpfr_t frx, fry;

long double sinfr(double d) {
  mpfr_set_d(frx, d, GMP_RNDN);
  mpfr_sin(fry, frx, GMP_RNDN);
  return mpfr_get_ld(fry, GMP_RNDN);
}

long double cosfr(double d) {
  mpfr_set_d(frx, d, GMP_RNDN);
  mpfr_cos(fry, frx, GMP_RNDN);
  return mpfr_get_ld(fry, GMP_RNDN);
}

long double tanfr(double d) {
  mpfr_set_d(frx, d, GMP_RNDN);
  mpfr_tan(fry, frx, GMP_RNDN);
  return mpfr_get_ld(fry, GMP_RNDN);
}

long double asinfr(double d) {
  mpfr_set_d(frx, d, GMP_RNDN);
  mpfr_asin(fry, frx, GMP_RNDN);
  return mpfr_get_ld(fry, GMP_RNDN);
}

long double acosfr(double d) {
  mpfr_set_d(frx, d, GMP_RNDN);
  mpfr_acos(fry, frx, GMP_RNDN);
  return mpfr_get_ld(fry, GMP_RNDN);
}

long double atanfr(double d) {
  mpfr_set_d(frx, d, GMP_RNDN);
  mpfr_atan(fry, frx, GMP_RNDN);
  return mpfr_get_ld(fry, GMP_RNDN);
}

long double expfr(double d) {
  mpfr_set_d(frx, d, GMP_RNDN);
  mpfr_exp(fry, frx, GMP_RNDN);
  return mpfr_get_ld(fry, GMP_RNDN);
}

long double logfr(double d) {
  mpfr_set_d(frx, d, GMP_RNDN);
  mpfr_log(fry, frx, GMP_RNDN);
  return mpfr_get_ld(fry, GMP_RNDN);
}

long double funcfr(int fnc, double d) {
  switch(fnc) {
  case 0: return sinfr(d);
  case 1: return cosfr(d);
  case 2: return tanfr(d);
  case 3: return asinfr(d);
  case 4: return acosfr(d);
  case 5: return atanfr(d);
  case 6: return logfr(d);
  case 7: return expfr(d);
  }
  return 0;
}

//

double funcsse(int fnc, int idx, double d) {
  double s[2] = { random()/(double)RAND_MAX*20000-10000,
		  random()/(double)RAND_MAX*20000-10000 };

  s[idx] = d;
  __m128d a = _mm_loadu_pd(s);

  switch(fnc) {
  case 0: a = _mm_sin_pd(a); break;
  case 1: a = _mm_cos_pd(a); break;
  case 2: a = _mm_tan_pd(a); break;
  case 3: a = _mm_asin_pd(a); break;
  case 4: a = _mm_acos_pd(a); break;
  case 5: a = _mm_atan_pd(a); break;
  case 6: a = _mm_log_pd(a); break;
  case 7: a = _mm_exp_pd(a); break;
  }

  _mm_storeu_pd(s, a);

  return s[idx];
}

#ifdef __AVX__
double funcavx(int fnc, int idx, double d) {
  double s[4] = { random()/(double)RAND_MAX*20000-10000,
		  random()/(double)RAND_MAX*20000-10000,
		  random()/(double)RAND_MAX*20000-10000,
		  random()/(double)RAND_MAX*20000-10000 };

  s[idx] = d;
  __m256d a = _mm256_loadu_pd(s);

  switch(fnc) {
  case 0: a = _mm256_sin_pd(a); break;
  case 1: a = _mm256_cos_pd(a); break;
  case 2: a = _mm256_tan_pd(a); break;
  case 3: a = _mm256_asin_pd(a); break;
  case 4: a = _mm256_acos_pd(a); break;
  case 5: a = _mm256_atan_pd(a); break;
  case 6: a = _mm256_log_pd(a); break;
  case 7: a = _mm256_exp_pd(a); break;
  }

  _mm256_storeu_pd(s, a);

  return s[idx];
}
#endif

long double ulp(double x) {
  x = fabs(x);
  int exp;

  if (x == 0) {
    return DBL_MIN;
  } else {
    frexp(x, &exp);
  }

  return ldexp(1.0, exp-53);
}

int main(int argc, char **argv) {
  if (argc != 5) {
    fprintf(stderr,"usage : %s <start> <finish> <step> <fnc>\n", argv[0]);
    exit(-1);
  }

  double start = atof(argv[1]);
  double finish = atof(argv[2]);
  double step = atof(argv[3]);
  int fnc = atoi(argv[4]);

  srandom(time(NULL));

  mpfr_set_default_prec(256);
  mpfr_inits(frx, fry, NULL);

  double d, totalerr = 0, maxerr = 0;
  double totalerr2 = 0, maxerr2 = 0;
  int cnt = 0;

  for(d = start+step;d < finish;d += step) {
    double d2 = d;
    long double x = funcsse(fnc, random() & 1, d2);
    long double y;

#ifdef __AVX__
    y = funcavx(fnc, random() & 3, d2);
#endif

    long double t = funcfr(fnc, d2);

    double err = fabs((x - t) / ulp(t));
    totalerr += err;

#ifdef __AVX__
    double err2 = fabs((y - t) / ulp(t));
    totalerr2 += err2;
#else
    double err2 = 0;
#endif

    if (err > 100 || err2 > 100) {
      printf("\nSTOP\n");
      printf("d = %.24g\n", d);
      printf("x = %.24Lg\n", x);
      printf("y = %.24Lg\n", x);
      printf("t = %.24Lg\n", t);
      exit(0);
    }

    if (err > maxerr) {
      //printf("d = %.24g, err = %g\n", d, err);
      maxerr = err;
    }

    if (err2 > maxerr2) {
      //printf("d = %.24g, err = %g\n", d, err);
      maxerr2 = err2;
    }

    cnt++;
  }

#ifdef __AVX__
  printf("avgerr = %.6g ulp (sse), %.6g ulp (avx), maxerr = %.6g ulp (sse), %.6g ulp (avx)\n", (totalerr / cnt), (totalerr2 / cnt), maxerr, maxerr2);
#else
  printf("avgerr = %.6g ulp, maxerr = %.6g ulp\n", (totalerr / cnt), maxerr);
#endif

  exit(0);
}
