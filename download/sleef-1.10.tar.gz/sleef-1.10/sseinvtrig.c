#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>

#include <emmintrin.h>

__m128d _mm_atan_pd(__m128d d) {
  __m128d d0, x, y, z;

  d0 = _mm_andnot_pd(_mm_set_pd(-0.0,-0.0), d);
  y = _mm_div_pd(_mm_set_pd(1.0, 1.0), d0);
  z = _mm_cmplt_pd(d0, _mm_set_pd(1.0, 1.0));
  x = _mm_andnot_pd(z, d0);
  y = _mm_and_pd(z, y);
  x = _mm_or_pd(x, y);

  y = _mm_mul_pd(x, x);
  y = _mm_add_pd(y, _mm_set_pd(1.0, 1.0));
  y = _mm_sqrt_pd(y);
  x = _mm_add_pd(x, y);

  y = _mm_mul_pd(x, x);
  y = _mm_add_pd(y, _mm_set_pd(1.0, 1.0));
  y = _mm_sqrt_pd(y);
  x = _mm_add_pd(x, y);

  x = _mm_div_pd(_mm_set_pd(1.0, 1.0), x);
  z = _mm_mul_pd(x, x);

  y = _mm_mul_pd(z, _mm_set_pd( 4.0/(10*2+1), 4.0/(10*2+1)));
  y = _mm_add_pd(y, _mm_set_pd(-4.0/( 9*2+1),-4.0/( 9*2+1)));
  y = _mm_mul_pd(z, y);
  y = _mm_add_pd(y, _mm_set_pd( 4.0/( 8*2+1), 4.0/( 8*2+1)));
  y = _mm_mul_pd(z, y);
  y = _mm_add_pd(y, _mm_set_pd(-4.0/( 7*2+1),-4.0/( 7*2+1)));
  y = _mm_mul_pd(z, y);
  y = _mm_add_pd(y, _mm_set_pd( 4.0/( 6*2+1), 4.0/( 6*2+1)));
  y = _mm_mul_pd(z, y);
  y = _mm_add_pd(y, _mm_set_pd(-4.0/( 5*2+1),-4.0/( 5*2+1)));
  y = _mm_mul_pd(z, y);
  y = _mm_add_pd(y, _mm_set_pd( 4.0/( 4*2+1), 4.0/( 4*2+1)));
  y = _mm_mul_pd(z, y);
  y = _mm_add_pd(y, _mm_set_pd(-4.0/( 3*2+1),-4.0/( 3*2+1)));
  y = _mm_mul_pd(z, y);
  y = _mm_add_pd(y, _mm_set_pd( 4.0/( 2*2+1), 4.0/( 2*2+1)));
  y = _mm_mul_pd(z, y);
  y = _mm_add_pd(y, _mm_set_pd(-4.0/( 1*2+1),-4.0/( 1*2+1)));
  y = _mm_mul_pd(z, y);
  y = _mm_add_pd(y, _mm_set_pd( 4.0/( 0*2+1), 4.0/( 0*2+1)));
  x = _mm_mul_pd(x, y);

  y = _mm_sub_pd(_mm_set_pd(M_PI/2, M_PI/2), x);
  z = _mm_cmplt_pd(d0, _mm_set_pd(1.0, 1.0));
  x = _mm_and_pd(z, x);
  y = _mm_andnot_pd(z, y);
  x = _mm_or_pd(x, y);
  d = _mm_and_pd(_mm_set_pd(-0.0,-0.0), d);
  x = _mm_or_pd(x, d);

  return x;
}

__m128d _mm_asin_pd(__m128d d) {
  __m128d x, y;
  x = _mm_add_pd(_mm_set_pd(1, 1), d);
  y = _mm_sub_pd(_mm_set_pd(1, 1), d);
  x = _mm_mul_pd(x, y);
  x = _mm_sqrt_pd(x);
  x = _mm_div_pd(d, x);
  x = _mm_atan_pd(x);
  return x;
}

__m128d _mm_acos_pd(__m128d d) {
  __m128d x, y;
  x = _mm_add_pd(_mm_set_pd(1, 1), d);
  y = _mm_sub_pd(_mm_set_pd(1, 1), d);
  x = _mm_mul_pd(x, y);
  x = _mm_sqrt_pd(x);
  x = _mm_div_pd(x, d);
  x = _mm_atan_pd(x);

  y = _mm_cmplt_pd(d, _mm_set_pd(0, 0));
  y = _mm_and_pd(y, _mm_set_pd(M_PI, M_PI));
  x = _mm_add_pd(x, y);

  return x;
}
