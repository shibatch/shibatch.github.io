#include <immintrin.h>

#define M_LN2 0.6931471805599453094172321214581766 // $\log_e 2$

typedef union cnv {
  unsigned long long int ulli;
  double dbl;
} cnv;

static inline double ulli2dbl(unsigned long long int ulli) { cnv c; c.ulli = ulli; return c.dbl; }

__m256d _mm256_log_pd(__m256d d) {
  __m256d x, y, z, ex, s;
  __m128i q, r;

  q = (__m128i)_mm256_extractf128_pd(d, 0);
  q = (__m128i)_mm_shuffle_ps((__m128)q, _mm_set_ps(0, 0, 0, 0), _MM_SHUFFLE(0,0,3,1));
  r = (__m128i)_mm256_extractf128_pd(d, 1);
  r = (__m128i)_mm_shuffle_ps(_mm_set_ps(0, 0, 0, 0), (__m128)r, _MM_SHUFFLE(3,1,0,0));
  q = _mm_or_si128(q, r);
  q = _mm_srli_epi32(q, 20);
  q = _mm_sub_epi32(q, _mm_set_epi32(0x3fe, 0x3fe, 0x3fe, 0x3fe));
  ex = _mm256_cvtepi32_pd(q);

  x = _mm256_and_pd(d, _mm256_set1_pd(ulli2dbl((1ULL << 52)-1)));
  s = _mm256_or_pd(x, _mm256_set1_pd(ulli2dbl(0x3feULL << 52)));

  x = _mm256_cmp_pd(s, _mm256_set1_pd(0.7071), _CMP_LT_OQ);
  x = _mm256_and_pd(x, _mm256_set1_pd(1));
  ex = _mm256_sub_pd(ex, x);
  x = _mm256_add_pd(x, _mm256_set1_pd(1));
  s = _mm256_mul_pd(s, x);

  x = _mm256_sub_pd(s, _mm256_set1_pd(1));
  y = _mm256_add_pd(s, _mm256_set1_pd(1));
  x = _mm256_div_pd(x, y);
  y = _mm256_mul_pd(x, x);

  z = _mm256_mul_pd(_mm256_set1_pd(2.0/19), y);
  z = _mm256_add_pd(_mm256_set1_pd(2.0/17), z);
  z = _mm256_mul_pd(z, y);
  z = _mm256_add_pd(_mm256_set1_pd(2.0/15), z);
  z = _mm256_mul_pd(z, y);
  z = _mm256_add_pd(_mm256_set1_pd(2.0/13), z);
  z = _mm256_mul_pd(z, y);
  z = _mm256_add_pd(_mm256_set1_pd(2.0/11), z);
  z = _mm256_mul_pd(z, y);
  z = _mm256_add_pd(_mm256_set1_pd(2.0/ 9), z);
  z = _mm256_mul_pd(z, y);
  z = _mm256_add_pd(_mm256_set1_pd(2.0/ 7), z);
  z = _mm256_mul_pd(z, y);
  z = _mm256_add_pd(_mm256_set1_pd(2.0/ 5), z);
  z = _mm256_mul_pd(z, y);
  z = _mm256_add_pd(_mm256_set1_pd(2.0/ 3), z);
  z = _mm256_mul_pd(z, y);
  z = _mm256_add_pd(_mm256_set1_pd(2.0/ 1), z);

  x = _mm256_mul_pd(x, z);

  z = _mm256_mul_pd(ex, _mm256_set1_pd(M_LN2));
  x = _mm256_add_pd(x, z);

  return x;
}

//

#if 0
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc,char **argv) {
  double d[4] = {atof(argv[1]), atof(argv[2]), atof(argv[3]), atof(argv[4])}, s[4];
  cnv cx, ct;
  int i;

  __m256d a = _mm256_loadu_pd(d);
  a = _mm256_log_pd(a);
  _mm256_storeu_pd(s, a);

  for(i=0;i<4;i++) {
    cx.dbl = s[i];
    ct.dbl = (double)log(atof(argv[1+i]));

    printf("%.30g\n", ct.dbl);
    printf("x %016llx %.24g\n", cx.ulli, cx.dbl);
    printf("t %016llx %.24g\n", ct.ulli, ct.dbl);
    printf("%d ulp\n", abs(cx.ulli - ct.ulli));
    printf("\n");
  }

  exit(0);
}
#endif
