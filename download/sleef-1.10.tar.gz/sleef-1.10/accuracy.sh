#!/bin/sh
make accuracytest
echo sin from -10 to 10 step 0.0001
./accuracytest -10 10 0.0001 0
echo cos from -10 to 10 step 0.0001
./accuracytest -10 10 0.0001 1
echo tan from -10 to 10 step 0.0001
./accuracytest -10 10 0.0001 2
echo asin from -1 to 1 step 0.00001
./accuracytest -1 1 0.00001 3
echo acos from -1 to 1 step 0.00001
./accuracytest -1 1 0.00001 4
echo atan from -10 to 10 step 0.0001
./accuracytest -1 1 0.0001 5
echo log from 0.001 to 10 step 0.0001
./accuracytest 0.001 10 0.0001 6
echo exp from -10 to 10 step 0.0001
./accuracytest -10 10 0.0001 7
