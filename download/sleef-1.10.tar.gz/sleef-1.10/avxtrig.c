#include <immintrin.h>

#define M_4_PI 1.273239544735162542821171882678754627704620361328125

#define PI4_A .7853981554508209228515625 // $\pi/4$ split into three parts
#define PI4_B .794662735614792836713604629039764404296875e-8
#define PI4_C .306161699786838294306516483068750264552437361480769e-16

#define RPOW2N (1.0 / (1 << 3))

typedef struct sincos256_t {
  __m256d s, c;
} sincos256_t;

sincos256_t _mm256_sincos_pd(__m256d d) {
  __m256d d0, w, x, y, z;
  __m128i q, q0;

  //

  d0 = _mm256_andnot_pd(_mm256_set1_pd(-0.0), d);
  x = _mm256_mul_pd(d0, _mm256_set1_pd(M_4_PI));
  x = _mm256_sub_pd(x, _mm256_set1_pd(0.5));
  q = _mm256_cvtpd_epi32(x);

  //

  q0 = _mm_and_si128(q, _mm_set_epi32(1, 1, 1, 1));
  q0 = _mm_add_epi32(q0, q);
  x = _mm256_cvtepi32_pd(q0);
  y = _mm256_mul_pd(x, _mm256_set1_pd(PI4_A));
  d0 = _mm256_sub_pd(d0, y);
  y = _mm256_mul_pd(x, _mm256_set1_pd(PI4_B));
  d0 = _mm256_sub_pd(d0, y);
  y = _mm256_mul_pd(x, _mm256_set1_pd(PI4_C));
  d0 = _mm256_sub_pd(d0, y);

  //

  x = _mm256_mul_pd(d0, _mm256_set1_pd(RPOW2N));

  x = _mm256_mul_pd(x, x);
  z = _mm256_mul_pd(x, _mm256_set1_pd(1.0/1814400));
  z = _mm256_sub_pd(z, _mm256_set1_pd(1.0/20160));
  z = _mm256_mul_pd(x, z);
  z = _mm256_add_pd(z, _mm256_set1_pd(1.0/360));
  z = _mm256_mul_pd(x, z);
  z = _mm256_sub_pd(z, _mm256_set1_pd(1.0/12));
  z = _mm256_mul_pd(x, z);
  z = _mm256_add_pd(z, _mm256_set1_pd(1));
  x = _mm256_mul_pd(x, z);

  y = _mm256_sub_pd(_mm256_set1_pd(4), x);
  x = _mm256_mul_pd(x, y);
  y = _mm256_sub_pd(_mm256_set1_pd(4), x);
  x = _mm256_mul_pd(x, y);
  y = _mm256_sub_pd(_mm256_set1_pd(4), x);
  x = _mm256_mul_pd(x, y);

  x = _mm256_mul_pd(x, _mm256_set1_pd(1.0/2));

  y = _mm256_sub_pd(_mm256_set1_pd(2), x);
  z = _mm256_mul_pd(x, y);
  z = _mm256_sqrt_pd(z);
  x = _mm256_sub_pd(_mm256_set1_pd(1), x);

  sincos256_t ret;

  // if (((q + 1) & 2) != 0) { s = sc.c; sc.c = sc.s; sc.s = s; }
  q0 = _mm_add_epi32(q, _mm_set_epi32(1, 1, 1, 1));
  q0 = _mm_and_si128(q0, _mm_set_epi32(2, 2, 2, 2));
  y = _mm256_cmp_pd(_mm256_set1_pd(0), _mm256_cvtepi32_pd(q0), _CMP_EQ_OQ);

  ret.s = _mm256_and_pd(y, z);
  w = _mm256_andnot_pd(y, x);
  ret.s = _mm256_or_pd(ret.s, w);

  ret.c = _mm256_and_pd(y, x);
  w = _mm256_andnot_pd(y, z);
  ret.c = _mm256_or_pd(ret.c, w);

  // if (((q & 4) != 0) != (d < 0)) sc.s = -sc.s;
  q0 = _mm_srli_epi32(q, 2);
  q0 = _mm_andnot_si128(q0, _mm_set_epi32(1, 1, 1, 1));
  q0 = _mm_sub_epi32(q0, _mm_set_epi32(1, 1, 1, 1));
  x = _mm256_cvtepi32_pd(q0);
  y = _mm256_xor_pd(d, (__m256d) x);
  y = _mm256_and_pd(y, _mm256_set1_pd(-0.0));
  ret.s = _mm256_or_pd(ret.s, y);

  // if (((q + 2) & 4) != 0) sc.c = -sc.c;
  q0 = _mm_add_epi32(q, _mm_set_epi32(2, 2, 2, 2));
  q0 = _mm_srli_epi32(q0, 2);
  q0 = _mm_andnot_si128(q0, _mm_set_epi32(1, 1, 1, 1));
  q0 = _mm_sub_epi32(q0, _mm_set_epi32(1, 1, 1, 1));
  x = _mm256_cvtepi32_pd(q0);
  y = _mm256_and_pd(x, _mm256_set1_pd(-0.0));
  ret.c = _mm256_or_pd(ret.c, y);

  //

  return ret;
}

__m256d _mm256_sin_pd(__m256d d) {
  sincos256_t sc = _mm256_sincos_pd(d);
  return sc.s;
}

__m256d _mm256_cos_pd(__m256d d) {
  sincos256_t sc = _mm256_sincos_pd(d);
  return sc.c;
}

__m256d _mm256_tan_pd(__m256d d) {
  sincos256_t sc = _mm256_sincos_pd(d);
  return _mm256_div_pd(sc.s, sc.c);
}

//

#if 0
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef union cnv {
  unsigned long long int ulli;
  double dbl;
} cnv;

int main(int argc,char **argv) {
  double d[4] = {atof(argv[1]), atof(argv[2]), atof(argv[3]), atof(argv[4])}, s[4];
  cnv cx, ct;
  int i;

  __m256d a = _mm256_loadu_pd(d);
  a = _mm256_tan_pd(a);
  _mm256_storeu_pd(s, a);

  for(i=0;i<4;i++) {
    cx.dbl = s[i];
    ct.dbl = (double)tan(atof(argv[1+i]));

    printf("%.30g\n", ct.dbl);
    printf("%0llx %.24g\n", cx.ulli, cx.dbl);
    printf("%0llx %.24g\n", ct.ulli, ct.dbl);
    printf("%d ulp\n", abs(cx.ulli - ct.ulli));
    printf("\n");
  }

  exit(0);
}
#endif
