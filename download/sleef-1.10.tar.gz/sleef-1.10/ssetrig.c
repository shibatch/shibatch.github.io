#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>

#include <emmintrin.h>

#define M_4_PI 1.273239544735162542821171882678754627704620361328125

#define PI4_A .7853981554508209228515625 // $\pi/4$ split into three parts
#define PI4_B .794662735614792836713604629039764404296875e-8
#define PI4_C .306161699786838294306516483068750264552437361480769e-16

#define RPOW2N (1.0 / (1 << 3))

typedef struct sincos_t {
  __m128d s, c;
} sincos_t;

sincos_t _mm_sincos_pd(__m128d d) {
  __m128d d0, w, x, y, z;
  __m128i q, q0;

  //

  d0 = _mm_andnot_pd(_mm_set_pd(-0.0,-0.0), d);
  x = _mm_mul_pd(d0, _mm_set_pd(M_4_PI, M_4_PI));
  x = _mm_sub_pd(x, _mm_set_pd(0.5, 0.5));
  q = _mm_cvtpd_epi32(x);

  //

  q0 = _mm_and_si128(q, _mm_set_epi32(1, 1, 1, 1));
  q0 = _mm_add_epi32(q0, q);
  x = _mm_cvtepi32_pd(q0);
  y = _mm_mul_pd(x, _mm_set_pd(PI4_A, PI4_A));
  d0 = _mm_sub_pd(d0, y);
  y = _mm_mul_pd(x, _mm_set_pd(PI4_B, PI4_B));
  d0 = _mm_sub_pd(d0, y);
  y = _mm_mul_pd(x, _mm_set_pd(PI4_C, PI4_C));
  d0 = _mm_sub_pd(d0, y);

  q = (__m128i)_mm_shuffle_ps((__m128)q, (__m128)q, _MM_SHUFFLE(1,1,0,0));

  //

  x = _mm_mul_pd(d0, _mm_set_pd(RPOW2N, RPOW2N));

  x = _mm_mul_pd(x, x);
  z = _mm_mul_pd(x, _mm_set_pd(1.0/1814400, 1.0/1814400));
  z = _mm_sub_pd(z, _mm_set_pd(1.0/20160, 1.0/20160));
  z = _mm_mul_pd(x, z);
  z = _mm_add_pd(z, _mm_set_pd(1.0/360, 1.0/360));
  z = _mm_mul_pd(x, z);
  z = _mm_sub_pd(z, _mm_set_pd(1.0/12, 1.0/12));
  z = _mm_mul_pd(x, z);
  z = _mm_add_pd(z, _mm_set_pd(1, 1));
  x = _mm_mul_pd(x, z);

  y = _mm_sub_pd(_mm_set_pd(4, 4), x);
  x = _mm_mul_pd(x, y);
  y = _mm_sub_pd(_mm_set_pd(4, 4), x);
  x = _mm_mul_pd(x, y);
  y = _mm_sub_pd(_mm_set_pd(4, 4), x);
  x = _mm_mul_pd(x, y);

  x = _mm_mul_pd(x, _mm_set_pd(1.0/2, 1.0/2));

  y = _mm_sub_pd(_mm_set_pd(2, 2), x);
  z = _mm_mul_pd(x, y);
  z = _mm_sqrt_pd(z);
  x = _mm_sub_pd(_mm_set_pd(1, 1), x);

  sincos_t ret;

  q0 = _mm_add_epi32(q, _mm_set_epi32(1, 1, 1, 1));
  q0 = _mm_and_si128(q0, _mm_set_epi32(2, 2, 2, 2));
  y = (__m128d) _mm_cmpeq_epi32(_mm_set_epi32(0, 0, 0, 0), q0);

  ret.s = _mm_and_pd(y, z);
  w = _mm_andnot_pd(y, x);
  ret.s = _mm_or_pd(ret.s, w);

  ret.c = _mm_and_pd(y, x);
  w = _mm_andnot_pd(y, z);
  ret.c = _mm_or_pd(ret.c, w);

  q0 = _mm_slli_epi32(q, 29);
  y = _mm_xor_pd(d, (__m128d) q0);
  y = _mm_and_pd(y, _mm_set_pd(-0.0, -0.0));
  ret.s = _mm_or_pd(ret.s, y);

  q0 = _mm_add_epi32(q, _mm_set_epi32(2, 2, 2, 2));
  q0 = _mm_slli_epi32(q0, 29);
  y = _mm_and_pd((__m128d) q0, _mm_set_pd(-0.0, -0.0));
  ret.c = _mm_or_pd(ret.c, y);

  //

  return ret;
}

__m128d _mm_sin_pd(__m128d d) {
  sincos_t sc = _mm_sincos_pd(d);
  return sc.s;
}

__m128d _mm_cos_pd(__m128d d) {
  sincos_t sc = _mm_sincos_pd(d);
  return sc.c;
}

__m128d _mm_tan_pd(__m128d d) {
  sincos_t sc = _mm_sincos_pd(d);
  return _mm_div_pd(sc.s, sc.c);
}

#if 0
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef union cnv {
  unsigned long long int ulli;
  double dbl;
} cnv;

int main(int argc,char **argv) {
  double d = atof(argv[1]);

  printf("d = %.30g\n", d);

  __m128d a = _mm_set_pd(d, d);
  a = _mm_tan_pd(a);
  double s[2];
  _mm_storeu_pd(s, a);

  cnv cx, ct;
  cx.dbl = s[0];
  ct.dbl = (double)tan(d);

  printf("%0llx %.24g\n", cx.ulli, cx.dbl);
  printf("%0llx %.24g\n", ct.ulli, ct.dbl);
  printf("%d ulp\n", abs(cx.ulli - ct.ulli));
}
#endif
