#include <emmintrin.h>

#define M_LN2 0.6931471805599453094172321214581766 // $\log_e 2$

#define L2U .69314718055966295651160180568695068359375
#define L2L .28235290563031577122588448175013436025525412068e-12

__m128d _mm_exp_pd(__m128d d) {
  __m128d x, y, z;
  __m128i q;

  x = _mm_mul_pd(d, _mm_set_pd(1/M_LN2, 1/M_LN2));
  q = _mm_cvtpd_epi32(x);
  x = _mm_cvtepi32_pd(q);
  y = _mm_mul_pd(x, _mm_set_pd(L2U, L2U));
  z = _mm_sub_pd(d, y);
  y = _mm_mul_pd(x, _mm_set_pd(L2L, L2L));
  x = _mm_sub_pd(z, y);
  x = _mm_mul_pd(x, _mm_set_pd(1.0/16, 1.0/16));

  y = _mm_mul_pd(x, _mm_set_pd(1.0/40320, 1.0/40320));
  y = _mm_add_pd(y, _mm_set_pd(1.0/ 5040, 1.0/ 5040));
  y = _mm_mul_pd(y, x);
  y = _mm_add_pd(y, _mm_set_pd(1.0/  720, 1.0/  720));
  y = _mm_mul_pd(y, x);
  y = _mm_add_pd(y, _mm_set_pd(1.0/  120, 1.0/  120));
  y = _mm_mul_pd(y, x);
  y = _mm_add_pd(y, _mm_set_pd(1.0/   24, 1.0/   24));
  y = _mm_mul_pd(y, x);
  y = _mm_add_pd(y, _mm_set_pd(1.0/    6, 1.0/    6));
  y = _mm_mul_pd(y, x);
  y = _mm_add_pd(y, _mm_set_pd(1.0/    2, 1.0/    2));
  y = _mm_mul_pd(y, x);
  y = _mm_add_pd(y, _mm_set_pd(1.0/    1, 1.0/    1));
  x = _mm_mul_pd(y, x);

  y = _mm_add_pd(x, _mm_set_pd(2, 2));
  x = _mm_mul_pd(x, y);
  y = _mm_add_pd(x, _mm_set_pd(2, 2));
  x = _mm_mul_pd(x, y);
  y = _mm_add_pd(x, _mm_set_pd(2, 2));
  x = _mm_mul_pd(x, y);
  y = _mm_add_pd(x, _mm_set_pd(2, 2));
  x = _mm_mul_pd(x, y);

  x = _mm_add_pd(x, _mm_set_pd(1, 1));

  q = _mm_add_epi32(q, _mm_set_epi32(0x0, 0x0, 0x3ff, 0x3ff));
  q = (__m128i)_mm_shuffle_ps((__m128)q, (__m128)q, _MM_SHUFFLE(1,3,0,3));
  y = (__m128d)_mm_slli_epi32(q, 20);

  x = _mm_mul_pd(x, y);

  return x;
}
