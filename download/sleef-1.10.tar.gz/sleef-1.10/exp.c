#include <math.h>

#ifndef M_LN2
#define M_LN2 0.6931471805599453094172321214581766 // $\log_e 2$
#endif

// $\log_e 2$ split into two parts
#define L2U .69314718055966295651160180568695068359375
#define L2L .28235290563031577122588448175013436025525412068e-12
   
#define N 4

double xexp(double d) {
  int q = (int)(d / M_LN2), i;
  double s = d - q * L2U - q * L2L, t;
   
  s = s * pow(2, -N); // Argument reduction
   
  // Evaluating Taylor series
  t = (((s/40320 + 1.0/5040)*s + 1.0/720)*s + 1.0/120)*s;
  t = ((((t + 1.0/24)*s + 1.0/6)*s + 1.0/2)*s + 1)*s;

  for(i=0;i<N;i++) { t = (2+t)*t; }
   
  return (t + 1) * pow(2, q);
}
