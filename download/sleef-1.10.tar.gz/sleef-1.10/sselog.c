#include <emmintrin.h>

#define M_LN2 0.6931471805599453094172321214581766 // $\log_e 2$

__m128d _mm_log_pd(__m128d d) {
  __m128d x, y, z, ex, s;
  __m128i q;

  q = _mm_and_si128((__m128i)d, _mm_set_epi32(((1 << 12)-1) << 20, 0, ((1 << 12)-1) << 20, 0));
  q = _mm_srli_epi32(q, 20);
  q = (__m128i)_mm_shuffle_ps((__m128)q, (__m128)q, _MM_SHUFFLE(0,0,3,1));
  q = _mm_sub_epi32(q, _mm_set_epi32(0x3fe, 0x3fe, 0x3fe, 0x3fe));
  ex = _mm_cvtepi32_pd(q);

  x = _mm_and_pd(d, (__m128d)_mm_set_epi32((1 << 20)-1, 0xffffffff, (1 << 20)-1, 0xffffffff));
  s = _mm_or_pd (x, (__m128d)_mm_set_epi32(0x3fe << 20, 0, 0x3fe << 20, 0));

  x = _mm_cmplt_pd(s, _mm_set_pd(0.7071, 0.7071));
  x = _mm_and_pd(x, _mm_set_pd(1, 1));
  ex = _mm_sub_pd(ex, x);
  x = _mm_add_pd(x, _mm_set_pd(1, 1));
  s = _mm_mul_pd(s, x);

  x = _mm_sub_pd(s, _mm_set_pd(1, 1));
  y = _mm_add_pd(s, _mm_set_pd(1, 1));
  x = _mm_div_pd(x, y);
  y = _mm_mul_pd(x, x);

  z = _mm_mul_pd(_mm_set_pd(2.0/19, 2.0/19), y);
  z = _mm_add_pd(_mm_set_pd(2.0/17, 2.0/17), z);
  z = _mm_mul_pd(z, y);
  z = _mm_add_pd(_mm_set_pd(2.0/15, 2.0/15), z);
  z = _mm_mul_pd(z, y);
  z = _mm_add_pd(_mm_set_pd(2.0/13, 2.0/13), z);
  z = _mm_mul_pd(z, y);
  z = _mm_add_pd(_mm_set_pd(2.0/11, 2.0/11), z);
  z = _mm_mul_pd(z, y);
  z = _mm_add_pd(_mm_set_pd(2.0/ 9, 2.0/ 9), z);
  z = _mm_mul_pd(z, y);
  z = _mm_add_pd(_mm_set_pd(2.0/ 7, 2.0/ 7), z);
  z = _mm_mul_pd(z, y);
  z = _mm_add_pd(_mm_set_pd(2.0/ 5, 2.0/ 5), z);
  z = _mm_mul_pd(z, y);
  z = _mm_add_pd(_mm_set_pd(2.0/ 3, 2.0/ 3), z);
  z = _mm_mul_pd(z, y);
  z = _mm_add_pd(_mm_set_pd(2.0/ 1, 2.0/ 1), z);

  x = _mm_mul_pd(x, z);

  z = _mm_mul_pd(ex, _mm_set_pd(M_LN2, M_LN2));
  x = _mm_add_pd(x, z);

  return x;
}
