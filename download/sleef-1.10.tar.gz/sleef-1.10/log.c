#include <math.h>

double xlog(double d) {
  int e, i;
   
  double m = frexp(d, &e);
  if (m < 0.7071) { m *= 2; e--; }
   
  double x = (m-1) / (m+1), y = 0;
   
  for(i=19;i>=1;i-=2) { y = y*x*x + 2.0/i; }
   
  return e*log(2) + x*y;
}
