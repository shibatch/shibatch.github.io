#include <immintrin.h>

#define M_PI 3.1415926535897932384626433832795029

__m256d _mm256_atan_pd(__m256d d) {
  __m256d d0, x, y, z;

  d0 = _mm256_andnot_pd(_mm256_set1_pd(-0.0), d);
  y = _mm256_div_pd(_mm256_set1_pd(1.0), d0);
  z = _mm256_cmp_pd(d0, _mm256_set1_pd(1.0), _CMP_LT_OQ);
  x = _mm256_andnot_pd(z, d0);
  y = _mm256_and_pd(z, y);
  x = _mm256_or_pd(x, y);

  y = _mm256_mul_pd(x, x);
  y = _mm256_add_pd(y, _mm256_set1_pd(1.0));
  y = _mm256_sqrt_pd(y);
  x = _mm256_add_pd(x, y);

  y = _mm256_mul_pd(x, x);
  y = _mm256_add_pd(y, _mm256_set1_pd(1.0));
  y = _mm256_sqrt_pd(y);
  x = _mm256_add_pd(x, y);

  x = _mm256_div_pd(_mm256_set1_pd(1.0), x);
  z = _mm256_mul_pd(x, x);

  y = _mm256_mul_pd(z, _mm256_set1_pd( 4.0/(10*2+1)));
  y = _mm256_add_pd(y, _mm256_set1_pd(-4.0/( 9*2+1)));
  y = _mm256_mul_pd(z, y);
  y = _mm256_add_pd(y, _mm256_set1_pd( 4.0/( 8*2+1)));
  y = _mm256_mul_pd(z, y);
  y = _mm256_add_pd(y, _mm256_set1_pd(-4.0/( 7*2+1)));
  y = _mm256_mul_pd(z, y);
  y = _mm256_add_pd(y, _mm256_set1_pd( 4.0/( 6*2+1)));
  y = _mm256_mul_pd(z, y);
  y = _mm256_add_pd(y, _mm256_set1_pd(-4.0/( 5*2+1)));
  y = _mm256_mul_pd(z, y);
  y = _mm256_add_pd(y, _mm256_set1_pd( 4.0/( 4*2+1)));
  y = _mm256_mul_pd(z, y);
  y = _mm256_add_pd(y, _mm256_set1_pd(-4.0/( 3*2+1)));
  y = _mm256_mul_pd(z, y);
  y = _mm256_add_pd(y, _mm256_set1_pd( 4.0/( 2*2+1)));
  y = _mm256_mul_pd(z, y);
  y = _mm256_add_pd(y, _mm256_set1_pd(-4.0/( 1*2+1)));
  y = _mm256_mul_pd(z, y);
  y = _mm256_add_pd(y, _mm256_set1_pd( 4.0/( 0*2+1)));
  x = _mm256_mul_pd(x, y);

  y = _mm256_sub_pd(_mm256_set1_pd(M_PI/2), x);
  z = _mm256_cmp_pd(d0, _mm256_set1_pd(1.0), _CMP_LT_OQ);
  x = _mm256_and_pd(z, x);
  y = _mm256_andnot_pd(z, y);
  x = _mm256_or_pd(x, y);
  d = _mm256_and_pd(_mm256_set1_pd(-0.0), d);
  x = _mm256_or_pd(x, d);

  return x;
}

__m256d _mm256_asin_pd(__m256d d) {
  __m256d x, y;
  x = _mm256_add_pd(_mm256_set1_pd(1), d);
  y = _mm256_sub_pd(_mm256_set1_pd(1), d);
  x = _mm256_mul_pd(x, y);
  x = _mm256_sqrt_pd(x);
  x = _mm256_div_pd(d, x);
  x = _mm256_atan_pd(x);
  return x;
}

__m256d _mm256_acos_pd(__m256d d) {
  __m256d x, y;
  x = _mm256_add_pd(_mm256_set1_pd(1), d);
  y = _mm256_sub_pd(_mm256_set1_pd(1), d);
  x = _mm256_mul_pd(x, y);
  x = _mm256_sqrt_pd(x);
  x = _mm256_div_pd(x, d);
  x = _mm256_atan_pd(x);

  y = _mm256_cmp_pd(d, _mm256_set1_pd(0), _CMP_LT_OQ);
  y = _mm256_and_pd(y, _mm256_set1_pd(M_PI));
  x = _mm256_add_pd(x, y);

  return x;
}

//

#if 0
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef union cnv {
  unsigned long long int ulli;
  double dbl;
} cnv;

int main(int argc,char **argv) {
  double d[4] = {atof(argv[1]), atof(argv[2]), atof(argv[3]), atof(argv[4])}, s[4];
  cnv cx, ct;
  int i;

  __m256d a = _mm256_loadu_pd(d);
  a = _mm256_atan_pd(a);
  _mm256_storeu_pd(s, a);

  for(i=0;i<4;i++) {
    cx.dbl = s[i];
    ct.dbl = (double)atan(atof(argv[1+i]));

    printf("%.30g\n", ct.dbl);
    printf("%0llx %.24g\n", cx.ulli, cx.dbl);
    printf("%0llx %.24g\n", ct.ulli, ct.dbl);
    printf("%d ulp\n", abs(cx.ulli - ct.ulli));
    printf("\n");
  }

  exit(0);
}
#endif
