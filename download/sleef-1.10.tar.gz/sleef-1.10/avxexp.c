#include <immintrin.h>

#define M_LN2 0.6931471805599453094172321214581766 // $\log_e 2$

#define L2U .69314718055966295651160180568695068359375
#define L2L .28235290563031577122588448175013436025525412068e-12

__m256d _mm256_exp_pd(__m256d d) {
  __m256d x, y, z;
  __m128i q, r;

  x = _mm256_mul_pd(d, _mm256_set1_pd(1/M_LN2));
  q = _mm256_cvtpd_epi32(x);
  x = _mm256_cvtepi32_pd(q);
  y = _mm256_mul_pd(x, _mm256_set1_pd(L2U));
  z = _mm256_sub_pd(d, y);
  y = _mm256_mul_pd(x, _mm256_set1_pd(L2L));
  x = _mm256_sub_pd(z, y);
  x = _mm256_mul_pd(x, _mm256_set1_pd(1.0/16));

  y = _mm256_mul_pd(x, _mm256_set1_pd(1.0/40320));
  y = _mm256_add_pd(y, _mm256_set1_pd(1.0/ 5040));
  y = _mm256_mul_pd(y, x);
  y = _mm256_add_pd(y, _mm256_set1_pd(1.0/  720));
  y = _mm256_mul_pd(y, x);
  y = _mm256_add_pd(y, _mm256_set1_pd(1.0/  120));
  y = _mm256_mul_pd(y, x);
  y = _mm256_add_pd(y, _mm256_set1_pd(1.0/   24));
  y = _mm256_mul_pd(y, x);
  y = _mm256_add_pd(y, _mm256_set1_pd(1.0/    6));
  y = _mm256_mul_pd(y, x);
  y = _mm256_add_pd(y, _mm256_set1_pd(1.0/    2));
  y = _mm256_mul_pd(y, x);
  y = _mm256_add_pd(y, _mm256_set1_pd(1.0/    1));
  x = _mm256_mul_pd(y, x);

  y = _mm256_add_pd(x, _mm256_set1_pd(2));
  x = _mm256_mul_pd(x, y);
  y = _mm256_add_pd(x, _mm256_set1_pd(2));
  x = _mm256_mul_pd(x, y);
  y = _mm256_add_pd(x, _mm256_set1_pd(2));
  x = _mm256_mul_pd(x, y);
  y = _mm256_add_pd(x, _mm256_set1_pd(2));
  x = _mm256_mul_pd(x, y);

  x = _mm256_add_pd(x, _mm256_set1_pd(1));

  q = _mm_add_epi32(q, _mm_set_epi32(0x3ff, 0x3ff, 0x3ff, 0x3ff));

  r = (__m128i)_mm_shuffle_ps((__m128)q, (__m128)q, _MM_SHUFFLE(1,0,0,0));
  r = _mm_slli_epi32(r, 20);
  r = _mm_and_si128(r, _mm_set_epi32(0xfff00000, 0, 0xfff00000, 0));
  y = _mm256_insertf128_pd(y, (__m128d)r, 0);

  r = (__m128i)_mm_shuffle_ps((__m128)q, (__m128)q, _MM_SHUFFLE(3,2,2,2));
  r = _mm_slli_epi32(r, 20);
  r = _mm_and_si128(r, _mm_set_epi32(0xfff00000, 0, 0xfff00000, 0));
  y = _mm256_insertf128_pd(y, (__m128d)r, 1);

  x = _mm256_mul_pd(x, y);

  return x;
}

//

#if 0
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef union cnv {
  unsigned long long int ulli;
  double dbl;
} cnv;

int main(int argc,char **argv) {
  double d[4] = {atof(argv[1]), atof(argv[2]), atof(argv[3]), atof(argv[4])}, s[4];
  cnv cx, ct;
  int i;

  __m256d a = _mm256_loadu_pd(d);
  a = _mm256_exp_pd(a);
  _mm256_storeu_pd(s, a);

  for(i=0;i<4;i++) {
    cx.dbl = s[i];
    ct.dbl = (double)exp(atof(argv[1+i]));

    printf("%.30g\n", ct.dbl);
    printf("%0llx %.24g\n", cx.ulli, cx.dbl);
    printf("%0llx %.24g\n", ct.ulli, ct.dbl);
    printf("%d ulp\n", abs(cx.ulli - ct.ulli));
    printf("\n");
  }

  exit(0);
}
#endif
