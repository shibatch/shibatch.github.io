typedef struct {
  double x, y;
} double2;

double xldexp(double x, int q);
int xilogb(double d);

double xsin(double d);
double xcos(double d);
double2 xsincos(double d);
double xtan(double d);
double xasin(double s);
double xacos(double s);
double xatan(double s);
double xatan2(double y, double x);
double xlog(double d);
double xexp(double d);
double xpow(double x, double y);

double xsinh(double x);
double xcosh(double x);
double xtanh(double x);
double xasinh(double x);
double xacosh(double x);
double xatanh(double x);
