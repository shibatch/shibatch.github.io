import java.io.*;

import org.naokishibata.sleef.*;

public class IUT {
    static long hexToLong(String s) {
	long ret = 0;
	for(int i=0;i<s.length();i++) {
	    char c = s.charAt(i);
	    ret <<= 4;
	    if ('0' <= c && c <= '9') ret += c - '0'; else ret += c - 'a' + 10;
	}
	return ret;
    }

    static String longToHex(long l) {
	if (l == 0) return "0";
	String str = "";
	while(l != 0) {
	    int d = (int)l & 0xf;
	    l = (l >>> 4) & 0x7fffffffffffffffL;
	    str = Character.forDigit(d, 16) + str;
	}
	return str;
    }

    public static void main(String[] args) throws Exception {
	LineNumberReader lnr = new LineNumberReader(new InputStreamReader(System.in));

	for(;;) {
	    String s = lnr.readLine();
	    if (s == null) break;

	    if (s.startsWith("atan2 ")) {
		String[] a = s.split(" ");
		long y = hexToLong(a[1]);
		long x = hexToLong(a[2]);
		double d = FastMath.atan2(Double.longBitsToDouble(y), Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("pow ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		long y = hexToLong(a[2]);
		double d = FastMath.pow(Double.longBitsToDouble(x), Double.longBitsToDouble(y));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("sincos ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		FastMath.double2 d2 = FastMath.sincos(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d2.x)) + " " + longToHex(Double.doubleToRawLongBits(d2.y)));
	    } else if (s.startsWith("sin ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.sin(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("cos ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.cos(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("tan ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.tan(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("asin ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.asin(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("acos ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.acos(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("atan ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.atan(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("log ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.log(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("exp ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.exp(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("sinh ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.sinh(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("cosh ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.cosh(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("tanh ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.tanh(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("asinh ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.asinh(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("acosh ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.acosh(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else if (s.startsWith("atanh ")) {
		String[] a = s.split(" ");
		long x = hexToLong(a[1]);
		double d = FastMath.atanh(Double.longBitsToDouble(x));
		System.out.println(longToHex(Double.doubleToRawLongBits(d)));
	    } else {
		break;
	    }

	    System.out.flush();
	}
    }
}
