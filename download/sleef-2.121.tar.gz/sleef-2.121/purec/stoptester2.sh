#!/bin/sh
killall tester2 tester2f
