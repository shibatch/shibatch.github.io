#!/bin/sh
killall tester2avx tester2avx2 tester2sse2 tester2avx512f tester2favx tester2favx2 tester2fsse2 tester2favx512f
