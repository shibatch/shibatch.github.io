#include <immintrin.h>

#ifdef ENABLE_SSE2
typedef __m128d vdouble;
#define VECTLEN 2

static vdouble vloadu(double *p) { return _mm_loadu_pd(p); }
static void vstoreu(double *p, vdouble v) { return _mm_storeu_pd(p, v); }
#endif

#ifdef ENABLE_AVX
typedef __m256d vdouble;
#define VECTLEN 4

static vdouble vloadu(double *p) { return _mm256_loadu_pd(p); }
static void vstoreu(double *p, vdouble v) { return _mm256_storeu_pd(p, v); }
#endif

typedef struct {
  vdouble x, y;
} vdouble2;

vdouble xsin(vdouble d);
vdouble xcos(vdouble d);
vdouble2 xsincos(vdouble d);
vdouble xtan(vdouble d);
vdouble xatan(vdouble s);
vdouble xatan2(vdouble y, vdouble x);
vdouble xlog(vdouble d);
vdouble xexp(vdouble d);
vdouble xpow(vdouble x, vdouble y);
