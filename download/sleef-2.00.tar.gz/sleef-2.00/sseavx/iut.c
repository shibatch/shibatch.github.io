#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#include <math.h>
#include <bits/nan.h>
#include <bits/inf.h>

#include <unistd.h>
#include <assert.h>
#include <sys/types.h>
#include <signal.h>

#include "sleefsseavx.h"

int readln(int fd, char *buf, int cnt) {
  int i, rcnt = 0;

  if (cnt < 1) return -1;

  while(cnt >= 2) {
    i = read(fd, buf, 1);
    if (i != 1) return i;

    if (*buf == '\n') break;

    rcnt++;
    buf++;
    cnt--;
  }

  *++buf = '\0';
  rcnt++;
  return rcnt;
}

int startsWith(char *str, char *prefix) {
  return strncmp(str, prefix, strlen(prefix)) == 0;
}

double u2d(uint64_t u) {
  union {
    double f;
    uint64_t i;
  } tmp;
  tmp.i = u;
  return tmp.f;
}

uint64_t d2u(double d) {
  union {
    double f;
    uint64_t i;
  } tmp;
  tmp.f = d;
  return tmp.i;
}

typedef struct {
  double x, y;
} double2;

double xxsin(double d) {
  double s[VECTLEN];
  int i;
  for(i=0;i<VECTLEN;i++) {
    s[i] = random()/(double)RAND_MAX*20000-10000;
  }
  int idx = random() & (VECTLEN-1);
  s[idx] = d;

  vdouble a = vloadu(s);
  a = xsin(a);
  vstoreu(s, a);

  return s[idx];
}

double xxcos(double d) {
  double s[VECTLEN];
  int i;
  for(i=0;i<VECTLEN;i++) {
    s[i] = random()/(double)RAND_MAX*20000-10000;
  }
  int idx = random() & (VECTLEN-1);
  s[idx] = d;

  vdouble a = vloadu(s);
  a = xcos(a);
  vstoreu(s, a);

  return s[idx];
}

double xxtan(double d) {
  double s[VECTLEN];
  int i;
  for(i=0;i<VECTLEN;i++) {
    s[i] = random()/(double)RAND_MAX*20000-10000;
  }
  int idx = random() & (VECTLEN-1);
  s[idx] = d;

  vdouble a = vloadu(s);
  a = xtan(a);
  vstoreu(s, a);

  return s[idx];
}

double xxatan(double d) {
  double s[VECTLEN];
  int i;
  for(i=0;i<VECTLEN;i++) {
    s[i] = random()/(double)RAND_MAX*20000-10000;
  }
  int idx = random() & (VECTLEN-1);
  s[idx] = d;

  vdouble a = vloadu(s);
  a = xatan(a);
  vstoreu(s, a);

  return s[idx];
}

double xxlog(double d) {
  double s[VECTLEN];
  int i;
  for(i=0;i<VECTLEN;i++) {
    s[i] = random()/(double)RAND_MAX*20000-10000;
  }
  int idx = random() & (VECTLEN-1);
  s[idx] = d;

  vdouble a = vloadu(s);
  a = xlog(a);
  vstoreu(s, a);

  return s[idx];
}

double xxexp(double d) {
  double s[VECTLEN];
  int i;
  for(i=0;i<VECTLEN;i++) {
    s[i] = random()/(double)RAND_MAX*20000-10000;
  }
  int idx = random() & (VECTLEN-1);
  s[idx] = d;

  vdouble a = vloadu(s);
  a = xexp(a);
  vstoreu(s, a);

  return s[idx];
}

double2 xxsincos(double d) {
  double s[VECTLEN], t[VECTLEN];
  int i;
  for(i=0;i<VECTLEN;i++) {
    s[i] = random()/(double)RAND_MAX*20000-10000;
    t[i] = random()/(double)RAND_MAX*20000-10000;
  }
  int idx = random() & (VECTLEN-1);

  s[idx] = d;

  vdouble2 v;

  vdouble a = vloadu(s);
  v = xsincos(a);
  vstoreu(s, v.x);
  vstoreu(t, v.y);

  double2 d2;
  d2.x = s[idx];
  d2.y = t[idx];

  return d2;
}

double xxpow(double x, double y) {
  double s[VECTLEN], t[VECTLEN];
  int i;
  for(i=0;i<VECTLEN;i++) {
    s[i] = random()/(double)RAND_MAX*20000-10000;
    t[i] = random()/(double)RAND_MAX*20000-10000;
  }
  int idx = random() & (VECTLEN-1);

  s[idx] = x;
  t[idx] = y;

  s[0] = x;
  s[1] = x;
  t[0] = y;
  t[1] = y;

  vdouble a, b;

  a = vloadu(s);
  b = vloadu(t);
  a = xpow(a, b);
  vstoreu(s, a);

  return s[idx];
}

double xxatan2(double y, double x) {
  double s[VECTLEN], t[VECTLEN];
  int i;
  for(i=0;i<VECTLEN;i++) {
    s[i] = random()/(double)RAND_MAX*20000-10000;
    t[i] = random()/(double)RAND_MAX*20000-10000;
  }
  int idx = random() & (VECTLEN-1);

  s[idx] = y;
  t[idx] = x;

  vdouble a, b;

  a = vloadu(s);
  b = vloadu(t);
  a = xatan2(a, b);
  vstoreu(s, a);

  return s[idx];
}

#define BUFSIZE 1024

int main(int argc, char **argv) {
  srandom(time(NULL));

  char buf[BUFSIZE];

  //fprintf(stderr, "IUT start\n");

  for(;;) {
    if (readln(STDIN_FILENO, buf, BUFSIZE-1) < 1) break;

    //fprintf(stderr, "iut: got %s\n", buf);

    if (startsWith(buf, "sin ")) {
      uint64_t u;
      sscanf(buf, "sin %lx", &u);
      u = d2u(xxsin(u2d(u)));
      printf("%lx\n", u);
    } else if (startsWith(buf, "cos ")) {
      uint64_t u;
      sscanf(buf, "cos %lx", &u);
      u = d2u(xxcos(u2d(u)));
      printf("%lx\n", u);
    } else if (startsWith(buf, "sincos ")) {
      uint64_t u;
      sscanf(buf, "sincos %lx", &u);
      double2 x = xxsincos(u2d(u));
      printf("%lx %lx\n", d2u(x.x), d2u(x.y));
    } else if (startsWith(buf, "tan ")) {
      uint64_t u;
      sscanf(buf, "tan %lx", &u);
      u = d2u(xxtan(u2d(u)));
      printf("%lx\n", u);
    } else if (startsWith(buf, "atan ")) {
      uint64_t u;
      sscanf(buf, "atan %lx", &u);
      /*
      {
	double d = u2d(u);
	fprintf(stderr, "arg = %g\n", d);
	d = xxatan(d);
	fprintf(stderr, "func = %g\n", d);
      }
      */
      u = d2u(xxatan(u2d(u)));
      printf("%lx\n", u);
    } else if (startsWith(buf, "log ")) {
      uint64_t u;
      sscanf(buf, "log %lx", &u);
      u = d2u(xxlog(u2d(u)));
      printf("%lx\n", u);
    } else if (startsWith(buf, "exp ")) {
      uint64_t u;
      sscanf(buf, "exp %lx", &u);
      u = d2u(xxexp(u2d(u)));
      printf("%lx\n", u);
    } else if (startsWith(buf, "atan2 ")) {
      uint64_t u, v;
      sscanf(buf, "atan2 %lx %lx", &u, &v);
      u = d2u(xxatan2(u2d(u), u2d(v)));
      printf("%lx\n", u);
    } else if (startsWith(buf, "pow ")) {
      uint64_t u, v;
      sscanf(buf, "pow %lx %lx", &u, &v);
      u = d2u(xxpow(u2d(u), u2d(v)));
      printf("%lx\n", u);
    }

    fflush(stdout);
  }

  return 0;
}
