#include <assert.h>
#include <math.h>
#include <bits/nan.h>
#include <bits/inf.h>

#ifdef ENABLE_SSE2
#include "helpersse2.h"
#endif

#ifdef ENABLE_AVX
#include "helperavx.h"
#endif

//

#define PI4_A .7853981554508209228515625
#define PI4_B .794662735614792836713604629039764404296875e-8
#define PI4_C .306161699786838294306516483068750264552437361480769e-16
#define M_4_PI 1.273239544735162542821171882678754627704620361328125

#define L2U .69314718055966295651160180568695068359375
#define L2L .28235290563031577122588448175013436025525412068e-12
#define R_LN2 1.442695040888963407359924681001892137426645954152985934135449406931

//

static inline vdouble vadd3(vdouble v0, vdouble v1, vdouble v2) {
  return vadd(vadd(v0, v1), v2);
}

static inline vdouble vadd4(vdouble v0, vdouble v1, vdouble v2, vdouble v3) {
  return vadd3(vadd(v0, v1), v2, v3);
}

static inline vdouble vadd5(vdouble v0, vdouble v1, vdouble v2, vdouble v3, vdouble v4) {
  return vadd4(vadd(v0, v1), v2, v3, v4);
}

static inline vdouble vsub3(vdouble v0, vdouble v1, vdouble v2) {
  return vsub(vsub(v0, v1), v2);
}

static inline vdouble vsub4(vdouble v0, vdouble v1, vdouble v2, vdouble v3) {
  return vsub3(vsub(v0, v1), v2, v3);
}

static inline vdouble vsub5(vdouble v0, vdouble v1, vdouble v2, vdouble v3, vdouble v4) {
  return vsub4(vsub(v0, v1), v2, v3, v4);
}

static inline vdouble vsub6(vdouble v0, vdouble v1, vdouble v2, vdouble v3, vdouble v4, vdouble v5) {
  return vsub5(vsub(v0, v1), v2, v3, v4, v5);
}

//

static inline vdouble2 normalize_d(vdouble2 t) {
  vdouble2 s;

  s.x = vadd(t.x, t.y);
  s.y = vadd(vsub(t.x, s.x), t.y);

  return s;
}

static inline vdouble2 scale_d(vdouble2 d, vdouble s) {
  vdouble2 r = {vmul(d.x, s), vmul(d.y, s)};
  return r;
}

static inline vdouble2 add_ss(vdouble x, vdouble y) {
  vdouble2 r;

  r.x = vadd(x, y);
  r.y = vadd(vsub(x, r.x), y);

  return r;
}

static inline vdouble2 add2_ss(vdouble x, vdouble y) {
  vdouble2 r;

  r.x = vadd(x, y);
  vdouble v = vsub(r.x, x);
  r.y = vadd(vsub(x, vsub(r.x, v)), vsub(y, v));

  return r;
}

static inline vdouble2 add_ds(vdouble2 x, vdouble y) {
  vdouble2 r;

  r.x = vadd(x.x, y);
  r.y = vadd3(vsub(x.x, r.x), y, x.y);

  return r;
}

static inline vdouble2 add2_ds(vdouble2 x, vdouble y) {
  vdouble2 r;

  r.x = vadd(x.x, y);
  vdouble v = vsub(r.x, x.x);
  r.y = vadd(vsub(x.x, vsub(r.x, v)), vsub(y, v));
  r.y = vadd(r.y, x.y);

  return r;
}

static inline vdouble2 add_sd(vdouble x, vdouble2 y) {
  vdouble2 r;

  r.x = vadd(x, y.x);
  r.y = vadd3(vsub(x, r.x), y.x, y.y);

  return r;
}

static inline vdouble2 add_dd(vdouble2 x, vdouble2 y) {
  // |x| >= |y|

  vdouble2 r;

  r.x = vadd(x.x, y.x);
  r.y = vadd4(vsub(x.x, r.x), y.x, x.y, y.y);

  return r;
}

static inline vdouble2 add2_dd(vdouble2 x, vdouble2 y) {
  vdouble2 r;

  r.x  = vadd(x.x, y.x);
  vdouble v = vsub(r.x, x.x);
  r.y = vadd(vsub(x.x, vsub(r.x, v)), vsub(y.x, v));
  r.y = vadd(r.y, vadd(x.y, y.y));

  return r;
}

static inline vdouble2 div_dd(vdouble2 n, vdouble2 d) {
  vdouble t = vrec(d.x);
  vdouble dh  = vupper(d.x), dl  = vsub(d.x,  dh);
  vdouble th  = vupper(t  ), tl  = vsub(t  ,  th);
  vdouble nhh = vupper(n.x), nhl = vsub(n.x, nhh);

  vdouble2 q;

  q.x = vmul(n.x, t);

  vdouble u = vadd5(vsub(vmul(nhh, th), q.x), vmul(nhh, tl), vmul(nhl, th), vmul(nhl, tl),
		    vmul(q.x, vsub5(vcast_vd_d(1), vmul(dh, th), vmul(dh, tl), vmul(dl, th), vmul(dl, tl))));

  q.y = vadd(vmul(t, vsub(n.y, vmul(q.x, d.y))), u);

  return q;
}

static inline vdouble2 mul_ds(vdouble2 x, vdouble y) {
  vdouble xh = vupper(x.x), xl = vsub(x.x, xh);
  vdouble yh = vupper(y  ), yl = vsub(y  , yh);
  vdouble2 r;

  r.x = vmul(xh, yh);
  r.y = vadd4(vmul(x.y, y), vmul(xl, yl), vmul(xh, yl), vmul(xl, yh));

  return r;
}

static inline vdouble2 mul_dd(vdouble2 x, vdouble2 y) {
  vdouble xh = vupper(x.x), xl = vsub(x.x, xh);
  vdouble yh = vupper(y.x), yl = vsub(y.x, yh);
  vdouble2 r;

  r.x = vmul(xh, yh);
  r.y = vadd5(vmul(x.y, y.x), vmul(x.x, y.y), vmul(xl, yl), vmul(xh, yl), vmul(xl, yh));

  return r;
}

static inline vdouble2 squ_d(vdouble2 x) {
  vdouble xhh = vupper(x.x), xhl = vsub(x.x, xhh);
  vdouble2 r;

  r.x = vmul(xhh, xhh);
  r.y = vadd3(vmul(x.y, vadd(x.x, x.x)), vmul(xhl, xhl), vmul(xhl, vadd(xhh, xhh)));

  return r;
}

//

vdouble xsin(vdouble d) {
  vint q;
  vdouble u, s;

  q = vrint_vi_vd(vmul(d, vcast_vd_d(M_1_PI)));

  u = vcast_vd_vi(q);
  d = vadd(d, vmul(u, vcast_vd_d(-PI4_A*4)));
  d = vadd(d, vmul(u, vcast_vd_d(-PI4_B*4)));
  d = vadd(d, vmul(u, vcast_vd_d(-PI4_C*4)));

  d = vsel(vmaski_eq(vandi(q, vcast_vi_i(1)), vcast_vi_i(1)), vneg(d), d);

  s = vmul(d, d);

  u = vcast_vd_d(-7.97255955009037868891952e-18);
  u = vmla(u, s, vcast_vd_d(2.81009972710863200091251e-15));
  u = vmla(u, s, vcast_vd_d(-7.64712219118158833288484e-13));
  u = vmla(u, s, vcast_vd_d(1.60590430605664501629054e-10));
  u = vmla(u, s, vcast_vd_d(-2.50521083763502045810755e-08));
  u = vmla(u, s, vcast_vd_d(2.75573192239198747630416e-06));
  u = vmla(u, s, vcast_vd_d(-0.000198412698412696162806809));
  u = vmla(u, s, vcast_vd_d(0.00833333333333332974823815));
  u = vmla(u, s, vcast_vd_d(-0.166666666666666657414808));

  u = vmla(s, vmul(u, d), d);

  return u;
}

vdouble xcos(vdouble d) {
  vint q;
  vdouble u, s;

  q = vrint_vi_vd(vsub(vmul(d, vcast_vd_d(M_1_PI)), vcast_vd_d(0.5)));
  q = vaddi(vaddi(q, q), vcast_vi_i(1));

  u = vcast_vd_vi(q);
  d = vadd(d, vmul(u, vcast_vd_d(-PI4_A*2)));
  d = vadd(d, vmul(u, vcast_vd_d(-PI4_B*2)));
  d = vadd(d, vmul(u, vcast_vd_d(-PI4_C*2)));

  d = vsel(vmaski_eq(vandi(q, vcast_vi_i(2)), vcast_vi_i(0)), vneg(d), d);

  s = vmul(d, d);

  u = vcast_vd_d(-7.97255955009037868891952e-18);
  u = vmla(u, s, vcast_vd_d(2.81009972710863200091251e-15));
  u = vmla(u, s, vcast_vd_d(-7.64712219118158833288484e-13));
  u = vmla(u, s, vcast_vd_d(1.60590430605664501629054e-10));
  u = vmla(u, s, vcast_vd_d(-2.50521083763502045810755e-08));
  u = vmla(u, s, vcast_vd_d(2.75573192239198747630416e-06));
  u = vmla(u, s, vcast_vd_d(-0.000198412698412696162806809));
  u = vmla(u, s, vcast_vd_d(0.00833333333333332974823815));
  u = vmla(u, s, vcast_vd_d(-0.166666666666666657414808));

  u = vmla(s, vmul(u, d), d);

  return u;
}

vdouble2 xsincos(vdouble d) {
  vint q, qq;
  vmask m;
  vdouble u, s, t, rx, ry;
  vdouble2 r;

  s = vabs(d);
  q = vrint_vi_vd(vadd(vmul(s, vcast_vd_d(M_4_PI)), vcast_vd_d(-0.5)));
  qq = vaddi(q, vandi(q, vcast_vi_i(1)));

  u = vcast_vd_vi(qq);
  s = vadd(s, vmul(u, vcast_vd_d(-PI4_A)));
  s = vadd(s, vmul(u, vcast_vd_d(-PI4_B)));
  s = vadd(s, vmul(u, vcast_vd_d(-PI4_C)));

  t = vabs(s);

  s = vmul(s, s);

  u = vcast_vd_d(-1.13615350239097429531523e-11);
  u = vmla(u, s, vcast_vd_d(2.08757471207040055479366e-09));
  u = vmla(u, s, vcast_vd_d(-2.75573144028847567498567e-07));
  u = vmla(u, s, vcast_vd_d(2.48015872890001867311915e-05));
  u = vmla(u, s, vcast_vd_d(-0.00138888888888714019282329));
  u = vmla(u, s, vcast_vd_d(0.0416666666666665519592062));
  u = vmla(u, s, vcast_vd_d(-0.5));

  ry = vadd(vcast_vd_d(1), vmul(s, u));

  u = vcast_vd_d(1.58938307283228937328511e-10);
  u = vmla(u, s, vcast_vd_d(-2.50506943502539773349318e-08));
  u = vmla(u, s, vcast_vd_d(2.75573131776846360512547e-06));
  u = vmla(u, s, vcast_vd_d(-0.000198412698278911770864914));
  u = vmla(u, s, vcast_vd_d(0.0083333333333191845961746));
  u = vmla(u, s, vcast_vd_d(-0.166666666666666130709393));
  u = vmul(u, vmul(s, t));

  rx = vadd(t, u);

  m = vmaski_eq(vandi(vaddi(q, vcast_vi_i(1)), vcast_vi_i(2)), vcast_vi_i(0));
  r.x = vsel(m, rx, ry);
  r.y = vsel(m, ry, rx);

  m = vmaski_eq(vandi(q, vcast_vi_i(4)), vcast_vi_i(0));
  m = vxorm(m, vmask_ge(d, vcast_vd_d(0)));
  r.x = vreinterpret_vd_vm(vxorm(vandm(m, vreinterpret_vm_vd(vcast_vd_d(-0.0))), vreinterpret_vm_vd(r.x)));

  m = vmaski_eq(vandi(vaddi(q, vcast_vi_i(2)), vcast_vi_i(4)), vcast_vi_i(4));
  r.y = vreinterpret_vd_vm(vxorm(vandm(m, vreinterpret_vm_vd(vcast_vd_d(-0.0))), vreinterpret_vm_vd(r.y)));

  m = vmask_isinf(d);
  r.x = vsel(m, vcast_vd_d(NAN), r.x);
  r.y = vsel(m, vcast_vd_d(NAN), r.y);

  return r;
}

vdouble xtan(vdouble d) {
  vint q;
  vdouble u, s, x;
  vmask m;

  q = vrint_vi_vd(vmul(d, vcast_vd_d(M_2_PI)));

  u = vcast_vd_vi(q);
  x = vadd(d, vmul(u, vcast_vd_d(-PI4_A*2)));
  x = vadd(x, vmul(u, vcast_vd_d(-PI4_B*2)));
  x = vadd(x, vmul(u, vcast_vd_d(-PI4_C*2)));

  m = vmaski_eq(vandi(q, vcast_vi_i(1)), vcast_vi_i(1));
  x = vsel(m, vneg(x), x);

  s = vmul(x, x);

  u = vcast_vd_d(1.01419718511083373224408e-05);
  u = vmla(u, s, vcast_vd_d(-2.59519791585924697698614e-05));
  u = vmla(u, s, vcast_vd_d(5.23388081915899855325186e-05));
  u = vmla(u, s, vcast_vd_d(-3.05033014433946488225616e-05));
  u = vmla(u, s, vcast_vd_d(7.14707504084242744267497e-05));
  u = vmla(u, s, vcast_vd_d(8.09674518280159187045078e-05));
  u = vmla(u, s, vcast_vd_d(0.000244884931879331847054404));
  u = vmla(u, s, vcast_vd_d(0.000588505168743587154904506));
  u = vmla(u, s, vcast_vd_d(0.00145612788922812427978848));
  u = vmla(u, s, vcast_vd_d(0.00359208743836906619142924));
  u = vmla(u, s, vcast_vd_d(0.00886323944362401618113356));
  u = vmla(u, s, vcast_vd_d(0.0218694882853846389592078));
  u = vmla(u, s, vcast_vd_d(0.0539682539781298417636002));
  u = vmla(u, s, vcast_vd_d(0.133333333333125941821962));
  u = vmla(u, s, vcast_vd_d(0.333333333333334980164153));

  u = vmla(s, vmul(u, x), x);

  u = vsel(m, vrec(u), u);

  u = vsel(vmask_isinf(d), vcast_vd_d(NAN), u);

  return u;
}

static inline vdouble atan2k(vdouble y, vdouble x) {
  vdouble s, t, u;
  vint q;
  vmask p;

  q = vseli_lt(x, vcast_vd_d(0), vcast_vi_i(-2), vcast_vi_i(0));
  x = vabs(x);

  q = vseli_lt(x, y, vaddi(q, vcast_vi_i(1)), q);
  p = vmask_lt(x, y);
  s = vsel (p, vneg(x), y);
  t = vmax (x, y);

  s = vdiv(s, t);
  t = vmul(s, s);

  u = vcast_vd_d(-1.88796008463073496563746e-05);
  u = vmla(u, t, vcast_vd_d(0.000209850076645816976906797));
  u = vmla(u, t, vcast_vd_d(-0.00110611831486672482563471));
  u = vmla(u, t, vcast_vd_d(0.00370026744188713119232403));
  u = vmla(u, t, vcast_vd_d(-0.00889896195887655491740809));
  u = vmla(u, t, vcast_vd_d(0.016599329773529201970117));
  u = vmla(u, t, vcast_vd_d(-0.0254517624932312641616861));
  u = vmla(u, t, vcast_vd_d(0.0337852580001353069993897));
  u = vmla(u, t, vcast_vd_d(-0.0407629191276836500001934));
  u = vmla(u, t, vcast_vd_d(0.0466667150077840625632675));
  u = vmla(u, t, vcast_vd_d(-0.0523674852303482457616113));
  u = vmla(u, t, vcast_vd_d(0.0587666392926673580854313));
  u = vmla(u, t, vcast_vd_d(-0.0666573579361080525984562));
  u = vmla(u, t, vcast_vd_d(0.0769219538311769618355029));
  u = vmla(u, t, vcast_vd_d(-0.090908995008245008229153));
  u = vmla(u, t, vcast_vd_d(0.111111105648261418443745));
  u = vmla(u, t, vcast_vd_d(-0.14285714266771329383765));
  u = vmla(u, t, vcast_vd_d(0.199999999996591265594148));
  u = vmla(u, t, vcast_vd_d(-0.333333333333311110369124));

  t = vadd(s, vmul(s, vmul(t, u)));
  t = vadd(t, vmul(vcast_vd_vi(q), vcast_vd_d(M_PI/2)));

  return t;
}

vdouble xatan2(vdouble y, vdouble x) {
  vdouble r = atan2k(vabs(y), x);

  r = vmulsign(r, x);
  r = vsel(vorm(vmask_isinf(x), vmask_eq(x, vcast_vd_d(0))), vsub(vcast_vd_d(M_PI/2), visinf2(x, vmulsign(vcast_vd_d(M_PI/2), x))), r);
  r = vsel(vmask_isinf(y), vsub(vcast_vd_d(M_PI/2), visinf2(x, vmulsign(vcast_vd_d(M_PI/4), x))), r);
  r = vsel(vmask_eq(y, vcast_vd_d(0)), vsel(vmask_eq(vsign(x), vcast_vd_d(-1.0)), vcast_vd_d(M_PI), vcast_vd_d(0)), r);

  return vsel(vorm(vmask_isnan(x), vmask_isnan(y)), vcast_vd_d(NAN), vmulsign(r, y));
}

vdouble xatan(vdouble s) {
  vdouble t, u;
  vint q;

  q = vseli_lt(s, vcast_vd_d(0), vcast_vi_i(2), vcast_vi_i(0));
  s = vabs(s);

  q = vseli_lt(vcast_vd_d(1), s, vaddi(q, vcast_vi_i(1)), q);
  s = vsel(vmask_lt(vcast_vd_d(1), s), vdiv(vcast_vd_d(1), s), s);

  t = vmul(s, s);

  u = vcast_vd_d(-1.88796008463073496563746e-05);
  u = vmla(u, t, vcast_vd_d(0.000209850076645816976906797));
  u = vmla(u, t, vcast_vd_d(-0.00110611831486672482563471));
  u = vmla(u, t, vcast_vd_d(0.00370026744188713119232403));
  u = vmla(u, t, vcast_vd_d(-0.00889896195887655491740809));
  u = vmla(u, t, vcast_vd_d(0.016599329773529201970117));
  u = vmla(u, t, vcast_vd_d(-0.0254517624932312641616861));
  u = vmla(u, t, vcast_vd_d(0.0337852580001353069993897));
  u = vmla(u, t, vcast_vd_d(-0.0407629191276836500001934));
  u = vmla(u, t, vcast_vd_d(0.0466667150077840625632675));
  u = vmla(u, t, vcast_vd_d(-0.0523674852303482457616113));
  u = vmla(u, t, vcast_vd_d(0.0587666392926673580854313));
  u = vmla(u, t, vcast_vd_d(-0.0666573579361080525984562));
  u = vmla(u, t, vcast_vd_d(0.0769219538311769618355029));
  u = vmla(u, t, vcast_vd_d(-0.090908995008245008229153));
  u = vmla(u, t, vcast_vd_d(0.111111105648261418443745));
  u = vmla(u, t, vcast_vd_d(-0.14285714266771329383765));
  u = vmla(u, t, vcast_vd_d(0.199999999996591265594148));
  u = vmla(u, t, vcast_vd_d(-0.333333333333311110369124));

  t = vadd(s, vmul(s, vmul(t, u)));

  t = vsel(vmaski_eq(vandi(q, vcast_vi_i(1)), vcast_vi_i(1)), vsub(vcast_vd_d(M_PI/2), t), t);
  t = vsel(vmaski_eq(vandi(q, vcast_vi_i(2)), vcast_vi_i(2)), vneg(t), t);

  return t;
}

vdouble xlog(vdouble d) {
  vdouble x, x2;
  vdouble t, m;
  vint e;

  e = vilogb(vmul(d, vcast_vd_d(0.7071)));
  m = vscalb(d, vsubi(vcast_vi_i(0), e));

  x = vdiv(vadd(vcast_vd_d(-1), m), vadd(vcast_vd_d(1), m));
  x2 = vmul(x, x);

  t = vcast_vd_d(0.148197055177935105296783);
  t = vmla(t, x2, vcast_vd_d(0.153108178020442575739679));
  t = vmla(t, x2, vcast_vd_d(0.181837339521549679055568));
  t = vmla(t, x2, vcast_vd_d(0.22222194152736701733275));
  t = vmla(t, x2, vcast_vd_d(0.285714288030134544449368));
  t = vmla(t, x2, vcast_vd_d(0.399999999989941956712869));
  t = vmla(t, x2, vcast_vd_d(0.666666666666685503450651));
  t = vmla(t, x2, vcast_vd_d(2));

  x = vadd(vmul(x, t), vmul(vcast_vd_d(0.693147180559945286226764), vcast_vd_vi(e)));

  x = vsel(vmask_isinf(d), vcast_vd_d(INFINITY), x);
  x = vsel(vmask_gt(vcast_vd_d(0), d), vcast_vd_d(NAN), x);
  x = vsel(vmask_eq(d, vcast_vd_d(0)), vcast_vd_d(-INFINITY), x);

  return x;
}

vdouble xexp(vdouble d) {
  vint q = vrint_vi_vd(vmul(d, vcast_vd_d(R_LN2)));
  vdouble s, u;

  s = vadd(d, vmul(vcast_vd_vi(q), vcast_vd_d(-L2U)));
  s = vadd(s, vmul(vcast_vd_vi(q), vcast_vd_d(-L2L)));

  u = vcast_vd_d(2.08860621107283687536341e-09);
  u = vmla(u, s, vcast_vd_d(2.51112930892876518610661e-08));
  u = vmla(u, s, vcast_vd_d(2.75573911234900471893338e-07));
  u = vmla(u, s, vcast_vd_d(2.75572362911928827629423e-06));
  u = vmla(u, s, vcast_vd_d(2.4801587159235472998791e-05));
  u = vmla(u, s, vcast_vd_d(0.000198412698960509205564975));
  u = vmla(u, s, vcast_vd_d(0.00138888888889774492207962));
  u = vmla(u, s, vcast_vd_d(0.00833333333331652721664984));
  u = vmla(u, s, vcast_vd_d(0.0416666666666665047591422));
  u = vmla(u, s, vcast_vd_d(0.166666666666666851703837));
  u = vmla(u, s, vcast_vd_d(0.5));

  u = vadd(vcast_vd_d(1), vadd(s, vmul(vmul(s, s), u)));

  u = vscalb(u, q);

  u = vsel(vandm(vmask_isinf(d), vmask_gt(vcast_vd_d(0), d)), vcast_vd_d(0), u);

  return u;
}

static inline vdouble2 logk(vdouble d) {
  vdouble2 x, x2;
  vdouble t, m;
  vint e;

  e = vilogb(vmul(d, vcast_vd_d(0.7071)));
  m = vscalb(d, vsubi(vcast_vi_i(0), e));

  x = div_dd(add2_ss(vcast_vd_d(-1), m), add2_ss(vcast_vd_d(1), m));
  x2 = squ_d(x);
  x2 = normalize_d(x2);

  t = vcast_vd_d(0.134601987501262130076155);
  t = vmla(t, x2.x, vcast_vd_d(0.132248509032032670243288));
  t = vmla(t, x2.x, vcast_vd_d(0.153883458318096079652524));
  t = vmla(t, x2.x, vcast_vd_d(0.181817427573705403298686));
  t = vmla(t, x2.x, vcast_vd_d(0.222222231326187414840781));
  t = vmla(t, x2.x, vcast_vd_d(0.285714285651261412873718));
  t = vmla(t, x2.x, vcast_vd_d(0.400000000000222439910458));
  t = vmla(t, x2.x, vcast_vd_d(0.666666666666666371239645));

  return add2_dd(mul_ds(dd(vcast_vd_d(0.693147180559945286226764), vcast_vd_d(2.319046813846299558417771e-17)),
		       vcast_vd_vi(e)),
		add2_dd(scale_d(x, vcast_vd_d(2)), mul_ds(mul_dd(x2, x), t)));
}

static inline vdouble expk(vdouble2 d) {
  vdouble u = vmul(vadd(d.x, d.y), vcast_vd_d(R_LN2));
  vint q = vrint_vi_vd(u);
  vdouble2 s, t;

  s = add2_ds(d, vmul(vcast_vd_vi(q), vcast_vd_d(-L2U)));
  s = add2_ds(s, vmul(vcast_vd_vi(q), vcast_vd_d(-L2L)));

  q = vrint_vi_vd(vmin(vmax(vcast_vd_d(-2047.49), u), vcast_vd_d(2047.49)));

  s = normalize_d(s);

  u = vcast_vd_d(2.51069683420950419527139e-08);
  u = vmla(u, s.x, vcast_vd_d(2.76286166770270649116855e-07));
  u = vmla(u, s.x, vcast_vd_d(2.75572496725023574143864e-06));
  u = vmla(u, s.x, vcast_vd_d(2.48014973989819794114153e-05));
  u = vmla(u, s.x, vcast_vd_d(0.000198412698809069797676111));
  u = vmla(u, s.x, vcast_vd_d(0.0013888888939977128960529));
  u = vmla(u, s.x, vcast_vd_d(0.00833333333332371417601081));
  u = vmla(u, s.x, vcast_vd_d(0.0416666666665409524128449));
  u = vmla(u, s.x, vcast_vd_d(0.166666666666666740681535));
  u = vmla(u, s.x, vcast_vd_d(0.500000000000000999200722));

  t = add_dd(s, mul_ds(squ_d(s), u));

  t = add_sd(vcast_vd_d(1), t);
  u = vadd(t.x, t.y);
  u = vscalb(u, q);

  return u;
}

vdouble xpow(vdouble x, vdouble y) {
#if 1
  vmask yisint = vmask_eq(vcast_vd_vi(vrint_vi_vd(y)), y);
  vmask yisodd = vandm(vmaski_eq(vandi(vrint_vi_vd(y), vcast_vi_i(1)), vcast_vi_i(1)), yisint);

  vdouble result = expk(mul_ds(logk(vabs(x)), y));

  //result = vsel(vmask_isnan(result), vcast_vd_d(INFINITY), result);

  result = vmul(result,
		vsel(vmask_gt(x, vcast_vd_d(0)),
		     vcast_vd_d(1),
		     vsel(yisint,
			  vsel(yisodd,
			       vcast_vd_d(-1),
			       vcast_vd_d(1)),
			  vcast_vd_d(NAN))));

  vdouble efx = vreinterpret_vd_vm(vxorm(vreinterpret_vm_vd(vsub(vabs(x), vcast_vd_d(1))), vsignbit(y)));

  result = vsel(vmask_isinf(y),
		vsel(vmask_lt(efx, vcast_vd_d(0)),
		     vcast_vd_d(0),
		     vsel(vmask_eq(efx, vcast_vd_d(0)),
			  vcast_vd_d(1.0),
			  vcast_vd_d(INFINITY))),
		result);

  result = vsel(vorm(vmask_isinf(x), vmask_eq(x, vcast_vd_d(0))),
		vmul(vsel(yisodd, vsign(x), vcast_vd_d(1)),
		     vsel(vmask_lt(vsel(vmask_eq(x, vcast_vd_d(0)), vneg(y), y), vcast_vd_d(0)),
			  vcast_vd_d(0),
			  vcast_vd_d(INFINITY))),
		result);

  result = vsel(vorm(vmask_isnan(x), vmask_isnan(y)), vcast_vd_d(NAN), result);

  result = vsel(vorm(vmask_eq(y, vcast_vd_d(0)), vmask_eq(x, vcast_vd_d(1))), vcast_vd_d(1), result);

  return result;
#else
  return expk(mul_ds(logk(x), y));
#endif
}
