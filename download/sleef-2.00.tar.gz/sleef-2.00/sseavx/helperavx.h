#ifndef __AVX__
#error Please specify -mavx.
#endif

#include <immintrin.h>
#include <stdint.h>

typedef __m256d vdouble;
typedef __m128i vint;
typedef __m256i vmask;

typedef __m128 vfloat;
typedef __m256 vfloat2;

//

static inline vint vrint_vi_vd(vdouble vd) { return _mm256_cvtpd_epi32(vd); }
static inline vdouble vcast_vd_vi(vint vi) { return _mm256_cvtepi32_pd(vi); }
static inline vdouble vcast_vd_d(double d) { return _mm256_set_pd(d, d, d, d); }
static inline vint vcast_vi_i(int i) { return _mm_set_epi32(i, i, i, i); }
static inline vmask vcast_vm_ii(int i, int j) { return _mm256_set_epi32(i, j, i, j, i, j, i, j); }

static inline vmask vcast_vm_u64(uint64_t u) { return _mm256_set_epi32((uint32_t)(u >> 32), (uint32_t)u, (uint32_t)(u >> 32), (uint32_t)u, (uint32_t)(u >> 32), (uint32_t)u, (uint32_t)(u >> 32), (uint32_t)u ); }

static inline vmask vreinterpret_vm_vd(vdouble vd) { return (__m256i)vd; }
static inline vdouble vreinterpret_vd_vm(vmask vm) { return (__m256d)vm;  }

static inline vfloat vreinterpret_vf_vi(vint vi) { return (__m128)vi; }
static inline vdouble vcast_vd_vf(vfloat vf) { return _mm256_cvtps_pd(vf); }

//

static inline vdouble vadd(vdouble x, vdouble y) { return _mm256_add_pd(x, y); }
static inline vdouble vsub(vdouble x, vdouble y) { return _mm256_sub_pd(x, y); }
static inline vdouble vmul(vdouble x, vdouble y) { return _mm256_mul_pd(x, y); }
static inline vdouble vdiv(vdouble x, vdouble y) { return _mm256_div_pd(x, y); }
static inline vdouble vrec(vdouble x) { return _mm256_div_pd(_mm256_set_pd(1, 1, 1, 1), x); }
static inline vdouble vmla(vdouble x, vdouble y, vdouble z) { return vadd(vmul(x, y), z); }

static inline vdouble vmax(vdouble x, vdouble y) { return _mm256_max_pd(x, y); }
static inline vdouble vmin(vdouble x, vdouble y) { return _mm256_min_pd(x, y); }

static inline vdouble vabs(vdouble d) { return (__m256d)_mm256_andnot_pd(_mm256_set_pd(-0.0,-0.0,-0.0,-0.0), d); }
static inline vdouble vneg(vdouble d) { return (__m256d)_mm256_xor_pd(_mm256_set_pd(-0.0,-0.0,-0.0,-0.0), d); }

//

static inline vmask vandm(vmask x, vmask y) { return (vmask)_mm256_and_pd((__m256d)x, (__m256d)y); }
static inline vmask vandnotm(vmask x, vmask y) { return (vmask)_mm256_andnot_pd((__m256d)x, (__m256d)y); }
static inline vmask vorm(vmask x, vmask y) { return (vmask)_mm256_or_pd((__m256d)x, (__m256d)y); }
static inline vmask vxorm(vmask x, vmask y) { return (vmask)_mm256_xor_pd((__m256d)x, (__m256d)y); }

static inline vmask vmask_eq(vdouble x, vdouble y) { return (__m256i)_mm256_cmp_pd(x, y, _CMP_EQ_OQ); }
static inline vmask vmask_neq(vdouble x, vdouble y) { return (__m256i)_mm256_cmp_pd(x, y, _CMP_NEQ_OQ); }
static inline vmask vmask_lt(vdouble x, vdouble y) { return (__m256i)_mm256_cmp_pd(x, y, _CMP_LT_OQ); }
static inline vmask vmask_le(vdouble x, vdouble y) { return (__m256i)_mm256_cmp_pd(x, y, _CMP_LE_OQ); }
static inline vmask vmask_gt(vdouble x, vdouble y) { return (__m256i)_mm256_cmp_pd(x, y, _CMP_GT_OQ); }
static inline vmask vmask_ge(vdouble x, vdouble y) { return (__m256i)_mm256_cmp_pd(x, y, _CMP_GE_OQ); }

//

static inline vint vaddi(vint x, vint y) { return _mm_add_epi32(x, y); }
static inline vint vsubi(vint x, vint y) { return _mm_sub_epi32(x, y); }

static inline vint vandi(vint x, vint y) { return _mm_and_si128(x, y); }
static inline vint vandnoti(vint x, vint y) { return _mm_andnot_si128(x, y); }
static inline vint vori(vint x, vint y) { return _mm_or_si128(x, y); }
static inline vint vxori(vint x, vint y) { return _mm_xor_si128(x, y); }

static inline vint vslli(vint x, int c) { return _mm_slli_epi64 (x, c); }
static inline vint vsrli(vint x, int c) { return _mm_srli_epi64 (x, c); }

//

static inline vmask vmaski_eq(vint x, vint y) {
  __m256d r = _mm256_cvtepi32_pd(_mm_and_si128(_mm_cmpeq_epi32(x, y), _mm_set_epi32(1, 1, 1, 1)));
  return vmask_eq(r, _mm256_set_pd(1, 1, 1, 1));
}

static inline vdouble vsel(vmask mask, vdouble x, vdouble y) {
  return (__m256d)vorm(vandm(mask, (__m256i)x), vandnotm(mask, (__m256i)y));
}

static inline vint vseli_lt(vdouble d0, vdouble d1, vint x, vint y) {
  __m128i mask = _mm256_cvtpd_epi32(_mm256_and_pd(_mm256_cmp_pd(d0, d1, _CMP_LT_OQ), _mm256_set_pd(1.0, 1.0, 1.0, 1.0)));
  mask = _mm_cmpeq_epi32(mask, _mm_set_epi32(1, 1, 1, 1));
  return vori(vandi(mask, x), vandnoti(mask, y));
}

static inline double vcast_d_vd(vdouble v) {
  double s[4];
  _mm256_storeu_pd(s, v);
  return s[0];
}

static inline vmask vsignbit(vdouble d) {
  return (vmask)_mm256_and_pd(d, _mm256_set_pd(-0.0,-0.0,-0.0,-0.0));
}

static inline vdouble vsign(vdouble d) {
  return _mm256_or_pd(_mm256_set_pd(1.0, 1.0, 1.0, 1.0), (vdouble)vsignbit(d));
}

static inline vdouble vmulsign(vdouble x, vdouble y) {
  return (__m256d)vxorm((__m256i)x, vsignbit(y));
}

static inline vmask vmask_isinf(vdouble d) {
  return (vmask)_mm256_cmp_pd(vabs(d), _mm256_set_pd(INFINITY, INFINITY, INFINITY, INFINITY), _CMP_EQ_OQ);
}

static inline vmask vmask_isnan(vdouble d) {
  return (vmask)_mm256_cmp_pd(d, d, _CMP_NEQ_UQ);
}

static inline vdouble visinf(vdouble d) {
  return _mm256_and_pd((vdouble)vmask_isinf(d), vsign(d));
}

static inline vdouble visinf2(vdouble d, vdouble m) {
  return _mm256_and_pd((vdouble)vmask_isinf(d), _mm256_or_pd((vdouble)vsignbit(d), m));
}

static inline vdouble vpow2i(vint q) {
  vint r;
  vdouble y;
  q = _mm_add_epi32(_mm_set_epi32(0x3ff, 0x3ff, 0x3ff, 0x3ff), q);
  q = _mm_slli_epi32(q, 20);
  r = (__m128i)_mm_shuffle_ps((__m128)q, (__m128)q, _MM_SHUFFLE(1,0,0,0));
  y = _mm256_castpd128_pd256((__m128d)r);
  r = (__m128i)_mm_shuffle_ps((__m128)q, (__m128)q, _MM_SHUFFLE(3,2,2,2));
  y = _mm256_insertf128_pd(y, (__m128d)r, 1);
  y = _mm256_and_pd(y, (__m256d)_mm256_set_epi32(0xfff00000, 0, 0xfff00000, 0, 0xfff00000, 0, 0xfff00000, 0));
  return y;
}

static inline vdouble vscalb(vdouble x, vint q) {
  vint m = _mm_srai_epi32(q, 31);
  m = _mm_slli_epi32(_mm_sub_epi32(_mm_srai_epi32(_mm_add_epi32(m, q), 10), m), 9);
  vdouble y = vpow2i(m);
  q = _mm_sub_epi32(_mm_sub_epi32(q, m), m);
  return vmul(vmul(vmul(x, y), y), vpow2i(q));
}

static inline vint vilogb(vdouble d) {
  vint q, r, c;
  vmask m = vmask_lt(d, vcast_vd_d(4.9090934652977266E-91));
  d = vsel(m, vmul(vcast_vd_d(2.037035976334486E90), d), d);
  c = _mm256_cvtpd_epi32(vsel(m, vcast_vd_d(300+0x3fe), vcast_vd_d(0x3fe)));
  q = (__m128i)_mm256_castpd256_pd128(d);
  q = (__m128i)_mm_shuffle_ps((__m128)q, _mm_set_ps(0, 0, 0, 0), _MM_SHUFFLE(0,0,3,1));
  r = (__m128i)_mm256_extractf128_pd(d, 1);
  r = (__m128i)_mm_shuffle_ps(_mm_set_ps(0, 0, 0, 0), (__m128)r, _MM_SHUFFLE(3,1,0,0));
  q = _mm_or_si128(q, r);
  q = _mm_srli_epi32(q, 20);
  q = _mm_sub_epi32(q, c);
  return q;
}

static inline vdouble vupper(vdouble d) {
  return (__m256d)_mm256_and_pd(d, (vdouble)_mm256_set_epi32(0xffffffff, 0xf8000000, 0xffffffff, 0xf8000000, 0xffffffff, 0xf8000000, 0xffffffff, 0xf8000000));
}

//

typedef struct {
  vdouble x, y;
} vdouble2;

static inline vdouble2 dd(vdouble h, vdouble l) {
  vdouble2 ret = {h, l};
  return ret;
}

static inline vdouble2 vsel2(vmask mask, vdouble2 x, vdouble2 y) {
  return dd((__m256d)vorm(vandm(mask, (__m256i)x.x), vandnotm(mask, (__m256i)y.x)),
	    (__m256d)vorm(vandm(mask, (__m256i)x.y), vandnotm(mask, (__m256i)y.y)));
}

static inline vdouble2 abs_d(vdouble2 x) {
  return dd((__m256d)_mm256_xor_pd(_mm256_and_pd(_mm256_set_pd(-0.0,-0.0,-0.0,-0.0), x.x), x.x),
	    (__m256d)_mm256_xor_pd(_mm256_and_pd(_mm256_set_pd(-0.0,-0.0,-0.0,-0.0), x.x), x.y));
}
