typedef struct {
  double x, y;
} double2;

double xsin(double d);
double xcos(double d);
double2 xsincos(double d);
double xtan(double d);
double xatan(double s);
double xatan2(double y, double x);
double xlog(double d);
double xexp(double d);
double xpow(double x, double y);
