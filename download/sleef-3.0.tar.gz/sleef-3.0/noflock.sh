#!/bin/sh
sh -c "$3"
