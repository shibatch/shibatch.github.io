#!/bin/sh
nohup nice ./tester2 >> ../tester2.out &
nohup nice ./tester2f >> ../tester2.out &
